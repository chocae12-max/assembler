; Average of five signed 32-bit integers
INCLUDE Irvine32.inc

.data
    prompt    BYTE "Enter an integer: ", 0
    resultMsg BYTE "Average: ", 0
    errorMsg  BYTE "Please enter a valid 32-bit integer.", 13, 10, 0
    sumLow    DWORD 0
    sumHigh   SDWORD 0
    wholePart SDWORD ?
    remainder SDWORD ?

.code
main PROC
    mov ecx, 5

inputLoop:
    push ecx
    mov edx, OFFSET prompt
    call WriteString
    call ReadInt
    pop ecx
    jo inputError

    ; Use a 64-bit sum to avoid overflow when adding five integers.
    cdq
    add sumLow, eax
    adc sumHigh, edx
    loop inputLoop

    ; EDX:EAX / 5 gives the integer part and the remainder.
    mov eax, sumLow
    mov edx, sumHigh
    mov ebx, 5
    idiv ebx
    mov wholePart, eax
    mov remainder, edx

    mov edx, OFFSET resultMsg
    call WriteString

    cmp sumHigh, 0
    jge showNumber
    mov al, '-'
    call WriteChar
    neg wholePart
    neg remainder

showNumber:
    mov eax, wholePart
    call WriteDec
    mov al, '.'
    call WriteChar

    ; A remainder of 1/5 is 0.2, so one decimal digit is enough.
    mov eax, remainder
    imul eax, 2
    call WriteDec
    call Crlf
    invoke ExitProcess, 0

inputError:
    mov edx, OFFSET errorMsg
    call WriteString
    invoke ExitProcess, 1
main ENDP
END main
