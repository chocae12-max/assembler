@echo off
cd /d "%~dp0"
average.exe
set "averageExitCode=%ERRORLEVEL%"
echo.
pause
exit /b %averageExitCode%
