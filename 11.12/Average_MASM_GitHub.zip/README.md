# 5개의 정수 평균 구하기

Visual Studio의 32비트 MASM에서 사용할 수 있는 어셈블리 프로그램이다.
정수 5개를 입력받고 평균을 소수점 첫째 자리까지 출력한다.

## 요구 조건

| 조건 | 구성 |
| --- | --- |
| Visual Studio의 32비트 MASM | Win32 프로젝트와 MASM 소스 포함 |
| 정수 5개 입력 | `ReadInt`를 다섯 번 호출 |
| 평균 출력 | 합계를 5로 나누고 소수점 첫째 자리까지 표시 |
| README에 실행 결과 화면 포함 | 아래 실행 캡처 포함 |

## 파일 구성

- `average.asm`: 어셈블리 소스
- `average.exe`: Windows용 32비트 콘솔 실행파일
- `run.bat`: 실행 후 결과 창을 유지하는 파일
- `Average.sln`, `Average.vcxproj`: Visual Studio 2022 프로젝트
- `build.bat`: Visual Studio 명령 프롬프트에서 빌드하는 파일
- `images/result.png`: 실행 결과 캡처

## 실행 방법

### 실행파일 사용

1. ZIP 압축을 모두 푼다.
2. Windows에서 `run.bat`을 실행한다.
3. 정수를 하나씩 입력하고 Enter를 누른다.

`run.bat`은 계산이 끝나도 창을 유지한다. `average.exe`를 직접 더블클릭하면
결과를 출력한 직후 창이 닫힐 수 있다.
실행파일 사용에는 Irvine32 개발 파일을 따로 설치하지 않아도 된다.

### Visual Studio에서 소스로 실행

1. Visual Studio Installer에서 **C++를 사용한 데스크톱 개발**을 설치한다.
2. [Irvine 공식 배포 페이지](https://github.com/surferkip/asmbook)에서 `Irvine.zip`을 받아,
   `C:\Irvine\Irvine32.inc`와 `C:\Irvine\Irvine32.lib`가 존재하도록 압축을 푼다.
3. `Average.sln`을 연다.
4. 솔루션 플랫폼을 **Win32**로 선택한다. C++ 프로젝트의 Win32는 x86(32비트)이다.
5. **Ctrl + F5**로 빌드하고 실행한다.

프로젝트는 Visual Studio 2022의 v143 도구 집합을 사용한다.
다른 버전에서 도구 집합을 찾지 못하면 프로젝트 속성의 **플랫폼 도구 집합**을
해당 컴퓨터에 설치된 버전으로 변경한다.
Irvine 설치 경로가 다르면 `Average.vcxproj`의 `IrvineDir` 값을 수정한다.

명령 프롬프트로 빌드하려면 **x86 Native Tools Command Prompt for VS**를 열어
이 폴더로 이동한 뒤 `build.bat`을 실행한다.

## 실행 결과

입력값은 `1, 2, 3, 4, 6`이며 평균은 `3.2`이다.

![정수 다섯 개를 입력하고 평균 3.2를 출력한 실행 화면](images/result.png)

캡처 환경은 Linux의 x86 에뮬레이터이다. 동봉한 Windows 실행파일의 명령과
Irvine32 루틴을 실행하고, Win32 콘솔 입출력 API를 에뮬레이션했다.

```text
Enter an integer: 1
Enter an integer: 2
Enter an integer: 3
Enter an integer: 4
Enter an integer: 6
Average: 3.2
```

## 소스 코드

```asm
; Average of five signed 32-bit integers
INCLUDE Irvine32.inc

.data
    prompt    BYTE "Enter an integer: ", 0
    resultMsg BYTE "Average: ", 0
    errorMsg  BYTE "Please enter a valid 32-bit integer.", 13, 10, 0
    sumLow    DWORD 0
    sumHigh   SDWORD 0
    wholePart SDWORD ?
    remainder SDWORD ?

.code
main PROC
    mov ecx, 5

inputLoop:
    push ecx
    mov edx, OFFSET prompt
    call WriteString
    call ReadInt
    pop ecx
    jo inputError

    ; Use a 64-bit sum to avoid overflow when adding five integers.
    cdq
    add sumLow, eax
    adc sumHigh, edx
    loop inputLoop

    ; EDX:EAX / 5 gives the integer part and the remainder.
    mov eax, sumLow
    mov edx, sumHigh
    mov ebx, 5
    idiv ebx
    mov wholePart, eax
    mov remainder, edx

    mov edx, OFFSET resultMsg
    call WriteString

    cmp sumHigh, 0
    jge showNumber
    mov al, '-'
    call WriteChar
    neg wholePart
    neg remainder

showNumber:
    mov eax, wholePart
    call WriteDec
    mov al, '.'
    call WriteChar

    ; A remainder of 1/5 is 0.2, so one decimal digit is enough.
    mov eax, remainder
    imul eax, 2
    call WriteDec
    call Crlf
    invoke ExitProcess, 0

inputError:
    mov edx, OFFSET errorMsg
    call WriteString
    invoke ExitProcess, 1
main ENDP
END main
```

## 계산 방법

1. `ReadInt`로 부호 있는 32비트 정수 5개를 입력받는다.
2. `cdq`, `add`, `adc`를 이용해 64비트 합계를 구한다.
3. `idiv`로 합계를 5로 나누어 정수 부분과 나머지를 구한다.
4. 나머지의 절댓값에 2를 곱해 소수 첫째 자리를 출력한다.

정수 다섯 개의 평균은 소수 부분이 `.0`, `.2`, `.4`, `.6`, `.8` 중 하나이므로
소수점 첫째 자리까지 표시하면 된다. 음수도 부호를 따로 출력하여 처리한다.
각 입력값의 범위는 **-2,147,483,648 ~ 2,147,483,647**이다.
입력은 한 줄에 정수 하나씩 넣는 것을 전제로 한다.

## 검증

MASM 호환 어셈블러 JWasm에서 오류 0개, 경고 0개로 어셈블했다.
실행파일은 JWasm과 GNU 링커로 만든 **PE32 / x86 / Windows 콘솔** 형식이다.
실제 Windows 및 Visual Studio에서의 빌드·실행 확인은 별도로 필요하다.

동봉 실행파일을 에뮬레이터에서 실행하여 정상 입력 12개와 오류 입력 2개를 확인했다.

| 입력 | 결과 |
| --- | --- |
| 1, 2, 3, 4, 6 | 3.2 |
| -1, -2, -3, -4, -5 | -3.0 |
| -1, 0, 0, 0, 0 | -0.2 |
| 0, 0, 0, 0, 0 | 0.0 |
| 2,147,483,647을 5번 입력 | 2147483647.0 |
| -2,147,483,648을 5번 입력 | -2147483648.0 |

## GitHub 업로드

압축을 푼 폴더의 내용 전체를 같은 저장소에 올린다.
특히 `images` 폴더를 그대로 올려야 README에서 실행 화면이 표시된다.

## 참고

- [Irvine: Visual Studio와 MASM 환경 설정](https://asmirvine.com/gettingStartedVS2022/index.htm)
- [Microsoft: C++ 프로젝트의 x86와 Win32 플랫폼](https://learn.microsoft.com/en-us/cpp/build/working-with-project-properties)
