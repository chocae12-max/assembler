@echo off
setlocal
cd /d "%~dp0"
if not defined IRVINE_DIR set "IRVINE_DIR=C:\Irvine"
where ml.exe >nul 2>nul
if errorlevel 1 (
    echo Open the x86 Native Tools Command Prompt for Visual Studio first.
    exit /b 1
)
if not exist "%IRVINE_DIR%\Irvine32.inc" (
    echo Irvine32.inc was not found in "%IRVINE_DIR%".
    echo Install the Irvine library there or set IRVINE_DIR.
    exit /b 1
)
ml.exe /nologo /c /coff /Zi /I "%IRVINE_DIR%" /Fo average.obj average.asm
if errorlevel 1 exit /b 1
link.exe /nologo /SUBSYSTEM:CONSOLE /MACHINE:X86 /ENTRY:_main@0 /SAFESEH:NO /OUT:average.exe /LIBPATH:"%IRVINE_DIR%" average.obj Irvine32.lib kernel32.lib user32.lib
if errorlevel 1 exit /b 1
echo Created average.exe
